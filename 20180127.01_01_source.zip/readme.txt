+=============================+
 ANIMATED BOOT INTRO BY DNA64
+=============================+

This .hmod installs an animated boot intro which will appear in full screen when the system boots up. A future version will include support for videos with embedded audio.

https://www.reddit.com/r/miniSNESmods/

Changelog:

v0.1 - January 27th, 2018

- DNA64 (aka viral_dna)
http://classicmods.net/repo
